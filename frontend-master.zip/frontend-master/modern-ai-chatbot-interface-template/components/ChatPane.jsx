"use client"

import { useState, forwardRef, useImperativeHandle, useRef } from "react"
import { Pencil, RefreshCw, Check, X, Square } from "lucide-react"
import Message from "./Message"
import Composer from "./Composer"
import { cls, timeAgo } from "./utils"

function ThinkingMessage({ onPause }) {
  return (
    <Message role="assistant">
      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1">
          <div className="h-2 w-2 animate-bounce rounded-full bg-primary/50 [animation-delay:-0.3s]"></div>
          <div className="h-2 w-2 animate-bounce rounded-full bg-primary/50 [animation-delay:-0.15s]"></div>
          <div className="h-2 w-2 animate-bounce rounded-full bg-primary/50"></div>
        </div>
        <span className="text-sm text-muted-foreground">Healthcare provider is responding...</span>
        <button
          onClick={onPause}
          className="ml-auto inline-flex items-center gap-1 rounded-full border border-border px-3 py-1 text-xs text-muted-foreground hover:bg-accent/20 transition-colors"
        >
          <Square className="h-3 w-3" /> Pause
        </button>
      </div>
    </Message>
  )
}

const ChatPane = forwardRef(function ChatPane(
  { conversation, onSend, onEditMessage, onResendMessage, isThinking, onPauseThinking },
  ref,
) {
  const [editingId, setEditingId] = useState(null)
  const [draft, setDraft] = useState("")
  const [busy, setBusy] = useState(false)
  const composerRef = useRef(null)

  useImperativeHandle(
    ref,
    () => ({
      insertTemplate: (templateContent) => {
        composerRef.current?.insertTemplate(templateContent)
      },
    }),
    [],
  )

  if (!conversation) return null

  const tags = ["Medical Professional", "Verified", "HIPAA Compliant", "Secure"]
  const messages = Array.isArray(conversation.messages) ? conversation.messages : []
  const count = messages.length || conversation.messageCount || 0

  function startEdit(m) {
    setEditingId(m.id)
    setDraft(m.content)
  }
  function cancelEdit() {
    setEditingId(null)
    setDraft("")
  }
  function saveEdit() {
    if (!editingId) return
    onEditMessage?.(editingId, draft)
    cancelEdit()
  }
  function saveAndResend() {
    if (!editingId) return
    onEditMessage?.(editingId, draft)
    onResendMessage?.(editingId)
    cancelEdit()
  }

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col bg-background">
      <div className="flex-1 space-y-6 overflow-y-auto px-6 py-8 sm:px-10">
        <div className="mb-8 border-b border-border pb-8">
          <h2 className="text-3xl font-bold text-primary mb-2">{conversation.title}</h2>
          <div className="flex flex-wrap gap-1 mb-4 text-xs text-muted-foreground">
            <span>Updated {timeAgo(conversation.updatedAt)}</span>
            <span>•</span>
            <span>{count} messages</span>
          </div>

          <div className="flex flex-wrap gap-2">
            {tags.map((t) => (
              <span
                key={t}
                className="inline-flex items-center rounded-full bg-accent/15 border border-accent/30 px-3 py-1.5 text-xs font-medium text-accent-foreground/80"
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        {messages.length === 0 ? (
          <div className="rounded-2xl border-2 border-dashed border-border bg-card/50 p-8 text-center">
            <p className="text-base text-muted-foreground">Send your first message to begin the consultation</p>
          </div>
        ) : (
          <>
            {messages.map((m) => (
              <div key={m.id} className="space-y-3">
                {editingId === m.id ? (
                  <div className={cls("rounded-2xl border-2 border-border p-3 bg-card", "dark:border-border")}>
                    <textarea
                      value={draft}
                      onChange={(e) => setDraft(e.target.value)}
                      className="w-full resize-y rounded-lg bg-input p-2 text-sm text-foreground outline-none focus:ring-2 focus:ring-primary/40"
                      rows={3}
                    />
                    <div className="mt-3 flex items-center gap-2">
                      <button
                        onClick={saveEdit}
                        className="inline-flex items-center gap-1 rounded-lg bg-primary text-primary-foreground px-4 py-2 text-xs font-medium hover:bg-primary/90 transition-colors"
                      >
                        <Check className="h-3.5 w-3.5" /> Save
                      </button>
                      <button
                        onClick={saveAndResend}
                        className="inline-flex items-center gap-1 rounded-lg border border-border bg-card px-4 py-2 text-xs font-medium hover:bg-muted transition-colors"
                      >
                        <RefreshCw className="h-3.5 w-3.5" /> Save & Resend
                      </button>
                      <button
                        onClick={cancelEdit}
                        className="inline-flex items-center gap-1 rounded-lg px-4 py-2 text-xs font-medium text-muted-foreground hover:bg-muted transition-colors"
                      >
                        <X className="h-3.5 w-3.5" /> Cancel
                      </button>
                    </div>
                  </div>
                ) : (
                  <Message role={m.role}>
                    <div className="whitespace-pre-wrap leading-relaxed">{m.content}</div>
                    {m.role === "user" && (
                      <div className="mt-2 flex gap-3 text-xs text-primary-foreground/70">
                        <button
                          className="inline-flex items-center gap-1 hover:underline opacity-80 hover:opacity-100"
                          onClick={() => startEdit(m)}
                        >
                          <Pencil className="h-3 w-3" /> Edit
                        </button>
                        <button
                          className="inline-flex items-center gap-1 hover:underline opacity-80 hover:opacity-100"
                          onClick={() => onResendMessage?.(m.id)}
                        >
                          <RefreshCw className="h-3 w-3" /> Resend
                        </button>
                      </div>
                    )}
                  </Message>
                )}
              </div>
            ))}
            {isThinking && <ThinkingMessage onPause={onPauseThinking} />}
          </>
        )}
      </div>

      <Composer
        ref={composerRef}
        onSend={async (text) => {
          if (!text.trim()) return
          setBusy(true)
          await onSend?.(text)
          setBusy(false)
        }}
        busy={busy}
      />
    </div>
  )
})

export default ChatPane
