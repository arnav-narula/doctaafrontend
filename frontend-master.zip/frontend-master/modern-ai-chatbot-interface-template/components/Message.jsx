import { cls } from "./utils"

export default function Message({ role, children }) {
  const isUser = role === "user"
  return (
    <div className={cls("flex gap-4", isUser ? "justify-end" : "justify-start")}>
      {!isUser && (
        <div className="mt-1 grid h-8 w-8 place-items-center rounded-full bg-primary text-xs font-bold text-primary-foreground flex-shrink-0">
          MD
        </div>
      )}
      <div
        className={cls(
          "max-w-[75%] rounded-2xl px-4 py-3 text-sm shadow-sm",
          isUser
            ? "bg-primary text-primary-foreground rounded-br-none"
            : "bg-card text-foreground border border-border rounded-bl-none",
        )}
      >
        {children}
      </div>
      {isUser && (
        <div className="mt-1 grid h-8 w-8 place-items-center rounded-full bg-muted text-xs font-bold text-muted-foreground flex-shrink-0">
          You
        </div>
      )}
    </div>
  )
}
