"use client"

import { Plus, Pin, Search, MessageCircle } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useState } from "react"

export default function ChatListView({ conversations, onSelectChat, onCreateChat, selectedBot }) {
  const [searchQuery, setSearchQuery] = useState("")

  // Group conversations by recency and filter by search
  const filteredConversations = conversations.filter(
    (conv) =>
      conv.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      conv.preview.toLowerCase().includes(searchQuery.toLowerCase()),
  )

  const pinnedChats = filteredConversations.filter((c) => c.pinned)
  const otherChats = filteredConversations
    .filter((c) => !c.pinned)
    .sort((a, b) => new Date(b.updatedAt) - new Date(a.updatedAt))

  return (
    <div className="h-screen w-full flex flex-col bg-background text-foreground">
      {/* Header */}
      <div className="flex-shrink-0 border-b border-border/50 bg-background px-6 py-4">
        <div className="flex items-center justify-between mb-3">
          <h1 className="text-2xl font-bold text-foreground">My Consultations</h1>
          <button
            onClick={onCreateChat}
            className="inline-flex items-center gap-2 rounded-md bg-foreground text-background px-3 py-2 font-semibold hover:bg-foreground/90 transition-colors text-sm"
          >
            <Plus className="h-4 w-4" />
            New
          </button>
        </div>

        {/* Search */}
        <div className="relative max-w-sm">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
          <input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-3 py-2 rounded-md border border-border bg-background text-foreground text-sm placeholder:text-muted-foreground focus:outline-none focus:ring-1 focus:ring-foreground/30 transition-all"
          />
        </div>
      </div>

      {/* Chat List */}
      <div className="flex-1 overflow-hidden min-h-0">
        <div className="h-full overflow-y-auto">
          <div className="px-6 py-4 pb-4">
            {pinnedChats.length > 0 && (
              <div className="mb-4">
                <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Pinned</h2>
                <div className="space-y-1">
                  {pinnedChats.map((conv) => (
                    <ChatListRow key={conv.id} chat={conv} onSelect={onSelectChat} />
                  ))}
                </div>
              </div>
            )}

            {otherChats.length > 0 && (
              <div>
                <h2 className="text-xs font-semibold text-muted-foreground uppercase tracking-wide mb-2">Recent</h2>
                <div className="space-y-1">
                  {otherChats.map((conv) => (
                    <ChatListRow key={conv.id} chat={conv} onSelect={onSelectChat} />
                  ))}
                </div>
              </div>
            )}

            {filteredConversations.length === 0 && (
              <div className="flex flex-col items-center justify-center py-12 text-center">
                <MessageCircle className="h-8 w-8 text-muted-foreground mb-3" />
                <h3 className="font-semibold text-base mb-1 text-foreground">No consultations yet</h3>
                <p className="text-sm text-muted-foreground mb-4">Start a new consultation</p>
                <button
                  onClick={onCreateChat}
                  className="inline-flex items-center gap-2 rounded-md bg-foreground text-background px-4 py-2 text-sm font-medium hover:bg-foreground/90 transition-colors"
                >
                  <Plus className="h-4 w-4" />
                  Start
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  )
}

function ChatListRow({ chat, onSelect }) {
  return (
    <button
      onClick={() => onSelect(chat.id)}
      className="w-full text-left px-3 py-2.5 rounded-md hover:bg-muted transition-colors group flex items-center justify-between gap-3"
    >
      <div className="flex-1 min-w-0">
        <div className="flex items-center gap-2">
          <h3 className="font-medium text-foreground truncate text-sm">{chat.title}</h3>
          {chat.pinned && <Pin className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />}
        </div>
        <p className="text-xs text-muted-foreground mt-0.5 line-clamp-1">{chat.preview}</p>
      </div>
      <div className="text-xs text-muted-foreground flex-shrink-0">
        {formatDistanceToNow(new Date(chat.updatedAt), { addSuffix: true })}
      </div>
    </button>
  )
}
