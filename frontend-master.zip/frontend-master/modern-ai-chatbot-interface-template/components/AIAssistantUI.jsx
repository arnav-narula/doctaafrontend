"use client"

import { useEffect, useRef, useState } from "react"
import { Asterisk, ChevronDown } from "lucide-react"
import ChatPane from "./ChatPane"
import ChatListView from "./ChatListView"
import ThemeToggle from "./ThemeToggle"
import { INITIAL_CONVERSATIONS } from "./mockData"

export default function AIAssistantUI() {
  const [theme, setTheme] = useState(() => {
    const saved = typeof window !== "undefined" && localStorage.getItem("theme")
    if (saved) return saved
    if (typeof window !== "undefined" && window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)").matches)
      return "dark"
    return "light"
  })

  useEffect(() => {
    try {
      if (theme === "dark") document.documentElement.classList.add("dark")
      else document.documentElement.classList.remove("dark")
      document.documentElement.setAttribute("data-theme", theme)
      document.documentElement.style.colorScheme = theme
      localStorage.setItem("theme", theme)
    } catch {}
  }, [theme])

  useEffect(() => {
    try {
      const media = window.matchMedia && window.matchMedia("(prefers-color-scheme: dark)")
      if (!media) return
      const listener = (e) => {
        const saved = localStorage.getItem("theme")
        if (!saved) setTheme(e.matches ? "dark" : "light")
      }
      media.addEventListener("change", listener)
      return () => media.removeEventListener("change", listener)
    } catch {}
  }, [])

  const [conversations, setConversations] = useState(INITIAL_CONVERSATIONS)
  const [selectedId, setSelectedId] = useState(null)
  const [selectedBot, setSelectedBot] = useState("Healthcare Provider")
  const [isDropdownOpen, setIsDropdownOpen] = useState(false)
  const [isThinking, setIsThinking] = useState(false)
  const [thinkingConvId, setThinkingConvId] = useState(null)
  const [view, setView] = useState("list")

  const chatbots = [
    { name: "Healthcare Provider", icon: "🩺" },
    { name: "Dr. Sarah Mitchell", icon: "👨‍⚕️" },
    { name: "Nurse Specialist", icon: "👩‍⚕️" },
    { name: "Medical Assistant", icon: <Asterisk className="h-4 w-4" /> },
  ]

  useEffect(() => {
    const onKey = (e) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "n") {
        e.preventDefault()
        createNewChat()
      }
    }
    window.addEventListener("keydown", onKey)
    return () => window.removeEventListener("keydown", onKey)
  }, [conversations])

  useEffect(() => {
    if (!selectedId && conversations.length > 0) {
      setSelectedId(conversations[0].id)
    }
  }, [])

  function createNewChat() {
    const id = Math.random().toString(36).slice(2)
    const item = {
      id,
      title: "New Consultation",
      updatedAt: new Date().toISOString(),
      messageCount: 0,
      preview: "Start your consultation...",
      pinned: false,
      folder: "Consultations",
      messages: [],
    }
    setConversations((prev) => [item, ...prev])
    setSelectedId(id)
    setView("chat")
  }

  function sendMessage(convId, content) {
    if (!content.trim()) return
    const now = new Date().toISOString()
    const userMsg = { id: Math.random().toString(36).slice(2), role: "user", content, createdAt: now }

    setConversations((prev) =>
      prev.map((c) => {
        if (c.id !== convId) return c
        const msgs = [...(c.messages || []), userMsg]
        return {
          ...c,
          messages: msgs,
          updatedAt: now,
          messageCount: msgs.length,
          preview: content.slice(0, 80),
        }
      }),
    )

    setIsThinking(true)
    setThinkingConvId(convId)

    const currentConvId = convId
    setTimeout(() => {
      setIsThinking(false)
      setThinkingConvId(null)
      setConversations((prev) =>
        prev.map((c) => {
          if (c.id !== currentConvId) return c
          const ack = `Thank you for your message. I've received it and will review your concerns shortly.`
          const asstMsg = {
            id: Math.random().toString(36).slice(2),
            role: "assistant",
            content: ack,
            createdAt: new Date().toISOString(),
          }
          const msgs = [...(c.messages || []), asstMsg]
          return {
            ...c,
            messages: msgs,
            updatedAt: new Date().toISOString(),
            messageCount: msgs.length,
            preview: asstMsg.content.slice(0, 80),
          }
        }),
      )
    }, 2000)
  }

  function editMessage(convId, messageId, newContent) {
    const now = new Date().toISOString()
    setConversations((prev) =>
      prev.map((c) => {
        if (c.id !== convId) return c
        const msgs = (c.messages || []).map((m) =>
          m.id === messageId ? { ...m, content: newContent, editedAt: now } : m,
        )
        return {
          ...c,
          messages: msgs,
          preview: msgs[msgs.length - 1]?.content?.slice(0, 80) || c.preview,
        }
      }),
    )
  }

  function resendMessage(convId, messageId) {
    const conv = conversations.find((c) => c.id === convId)
    const msg = conv?.messages?.find((m) => m.id === messageId)
    if (!msg) return
    sendMessage(convId, msg.content)
  }

  function pauseThinking() {
    setIsThinking(false)
    setThinkingConvId(null)
  }

  const composerRef = useRef(null)
  const selected = conversations.find((c) => c.id === selectedId) || null

  if (view === "list") {
    return (
      <ChatListView
        conversations={conversations}
        onSelectChat={(id) => {
          setSelectedId(id)
          setView("chat")
        }}
        onCreateChat={createNewChat}
        selectedBot={selectedBot}
      />
    )
  }

  return (
    <div className="h-screen w-full bg-background text-foreground flex flex-col">
      <div className="sticky top-0 z-30 flex items-center gap-3 border-b border-border bg-card/80 px-6 py-4 backdrop-blur supports-[backdrop-filter]:bg-card/60">
        <button
          onClick={() => setView("list")}
          className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium hover:bg-muted transition-colors"
        >
          ← Back to Consultations
        </button>

        <div className="flex relative ml-auto">
          <button
            onClick={() => setIsDropdownOpen(!isDropdownOpen)}
            className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-semibold hover:bg-muted focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary transition-colors"
          >
            {typeof chatbots.find((bot) => bot.name === selectedBot)?.icon === "string" ? (
              <span className="text-base">{chatbots.find((bot) => bot.name === selectedBot)?.icon}</span>
            ) : (
              chatbots.find((bot) => bot.name === selectedBot)?.icon
            )}
            {selectedBot}
            <ChevronDown className="h-4 w-4" />
          </button>

          {isDropdownOpen && (
            <div className="absolute top-full right-0 mt-2 w-56 rounded-lg border border-border bg-card shadow-lg z-50">
              {chatbots.map((bot) => (
                <button
                  key={bot.name}
                  onClick={() => {
                    setSelectedBot(bot.name)
                    setIsDropdownOpen(false)
                  }}
                  className="w-full flex items-center gap-3 px-4 py-3 text-sm text-left hover:bg-muted transition-colors first:rounded-t-lg last:rounded-b-lg"
                >
                  {typeof bot.icon === "string" ? <span className="text-base">{bot.icon}</span> : bot.icon}
                  <span className="font-medium">{bot.name}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        <div className="ml-3">
          <ThemeToggle theme={theme} setTheme={setTheme} />
        </div>
      </div>

      <main className="flex-1 w-full flex flex-col overflow-hidden">
        <ChatPane
          ref={composerRef}
          conversation={selected}
          onSend={(content) => selected && sendMessage(selected.id, content)}
          onEditMessage={(messageId, newContent) => selected && editMessage(selected.id, messageId, newContent)}
          onResendMessage={(messageId) => selected && resendMessage(selected.id, messageId)}
          isThinking={isThinking && thinkingConvId === selected?.id}
          onPauseThinking={pauseThinking}
        />
      </main>
    </div>
  )
}
