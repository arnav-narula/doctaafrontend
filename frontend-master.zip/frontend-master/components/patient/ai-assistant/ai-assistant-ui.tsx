"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import type { Conversation } from "@/components/doctor/ai-assistant/types"
import { ChatPane, type ChatPaneHandle } from "@/components/doctor/ai-assistant/chat-pane"
import { ChatListView } from "@/components/doctor/ai-assistant/chat-list-view"
import { PATIENT_INITIAL_CONVERSATIONS } from "./mock-data"

const chatbots = [
  { name: "AI Doctor", icon: "🩺" },
  { name: "Symptom Checker", icon: "🤖" },
  { name: "Wellness Coach", icon: "💪" },
]

export function PatientAIAssistantUI() {
  const [conversations, setConversations] = useState<Conversation[]>(PATIENT_INITIAL_CONVERSATIONS)
  const [selectedId, setSelectedId] = useState<string | null>(PATIENT_INITIAL_CONVERSATIONS[0]?.id ?? null)
  const [selectedBot, setSelectedBot] = useState(chatbots[0]?.name ?? "AI Doctor")
  const [isThinking, setIsThinking] = useState(false)
  const [thinkingId, setThinkingId] = useState<string | null>(null)
  const paneRef = useRef<ChatPaneHandle | null>(null)

  const selectedConversation = conversations.find((conversation) => conversation.id === selectedId) ?? null

  const createNewChat = useCallback(() => {
    const id = Math.random().toString(36).slice(2)
    const newConversation: Conversation = {
      id,
      title: "New question",
      updatedAt: new Date().toISOString(),
      messageCount: 0,
      preview: "Describe your symptoms to get started...",
      pinned: false,
      folder: "My chats",
      messages: [],
    }
    setConversations((prev) => [newConversation, ...prev])
    setSelectedId(id)
  }, [])

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "n") {
        event.preventDefault()
        createNewChat()
      }
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [createNewChat])

  const sendMessage = (conversationId: string, content: string) => {
    if (!content.trim()) return
    const now = new Date().toISOString()
    const userMessage = { id: Math.random().toString(36).slice(2), role: "user" as const, content, createdAt: now }

    setConversations((prev) =>
      prev.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              messages: [...conversation.messages, userMessage],
              updatedAt: now,
              messageCount: conversation.messages.length + 1,
              preview: content.slice(0, 80),
            }
          : conversation,
      ),
    )

    setIsThinking(true)
    setThinkingId(conversationId)

    setTimeout(() => {
      setIsThinking(false)
      setThinkingId(null)
      setConversations((prev) =>
        prev.map((conversation) =>
          conversation.id === conversationId
            ? {
                ...conversation,
                messages: [
                  ...conversation.messages,
                  {
                    id: Math.random().toString(36).slice(2),
                    role: "assistant" as const,
                    content:
                      "Thanks for the details. Based on what you shared, here's what you can try next. If symptoms worsen, book a visit.",
                    createdAt: new Date().toISOString(),
                  },
                ],
                updatedAt: new Date().toISOString(),
                messageCount: conversation.messages.length + 2,
                preview: "Thanks for the details...",
              }
            : conversation,
        ),
      )
    }, 2000)
  }

  const editMessage = (conversationId: string, messageId: string, newContent: string) => {
    setConversations((prev) =>
      prev.map((conversation) => {
        if (conversation.id !== conversationId) return conversation
        const updatedMessages = conversation.messages.map((message) =>
          message.id === messageId ? { ...message, content: newContent, editedAt: new Date().toISOString() } : message,
        )
        return {
          ...conversation,
          messages: updatedMessages,
          preview: updatedMessages.at(-1)?.content.slice(0, 80) ?? conversation.preview,
        }
      }),
    )
  }

  const resendMessage = (conversationId: string, messageId: string) => {
    const conversation = conversations.find((conv) => conv.id === conversationId)
    const message = conversation?.messages.find((msg) => msg.id === messageId)
    if (!conversation || !message) return

    const now = new Date().toISOString()

    setConversations((prev) =>
      prev.map((conv) => {
        if (conv.id !== conversationId) return conv
        const messages = conv.messages ?? []
        const index = messages.findIndex((m) => m.id === messageId)
        if (index === -1) return conv
        const trimmed = messages.slice(0, index + 1)
        return {
          ...conv,
          messages: trimmed,
          updatedAt: now,
          messageCount: trimmed.length,
          preview: trimmed.at(-1)?.content.slice(0, 80) ?? conv.preview,
        }
      }),
    )

    setIsThinking(true)
    setThinkingId(conversationId)

    setTimeout(() => {
      setIsThinking(false)
      setThinkingId(null)
      setConversations((prev) =>
        prev.map((conv) => {
          if (conv.id !== conversationId) return conv
          const messages = conv.messages ?? []
          const assistantMessage = {
            id: Math.random().toString(36).slice(2),
            role: "assistant" as const,
            content:
              "Here's an updated suggestion based on your edit. If you're unsure, reach out to a clinician for personal care.",
            createdAt: new Date().toISOString(),
          }
          return {
            ...conv,
            messages: [...messages, assistantMessage],
            updatedAt: new Date().toISOString(),
            messageCount: messages.length + 1,
            preview: "Here's an updated suggestion...",
          }
        }),
      )
    }, 2000)
  }

  const togglePin = useCallback((conversationId: string) => {
    setConversations((prev) =>
      prev.map((conversation) =>
        conversation.id === conversationId ? { ...conversation, pinned: !conversation.pinned } : conversation,
      ),
    )
  }, [])

  return (
    <div className="flex h-full flex-1 flex-col overflow-hidden">
      <div className="grid h-full grid-cols-1 lg:grid-cols-[360px_1fr]">
        <div className="border-b bg-muted/30 lg:border-b-0 lg:border-r">
          <ChatListView
            conversations={conversations}
            onSelectChat={(id) => setSelectedId(id)}
            onCreateChat={createNewChat}
            onTogglePin={togglePin}
          />
        </div>
        <div className="flex h-full flex-col">
          <div className="flex items-center justify-between border-b px-4 py-3">
            <div className="flex items-center gap-2">
              <span className="text-sm text-muted-foreground">Talking with</span>
              <select
                className="rounded-lg border bg-background px-2 py-1 text-sm"
                value={selectedBot}
                onChange={(event) => setSelectedBot(event.target.value)}
              >
                {chatbots.map((bot) => (
                  <option key={bot.name} value={bot.name}>
                    {bot.icon} {bot.name}
                  </option>
                ))}
              </select>
            </div>
            <button
              type="button"
              onClick={createNewChat}
              className="inline-flex items-center gap-2 rounded-full bg-foreground px-3 py-1.5 text-sm font-medium text-background transition hover:bg-foreground/90"
            >
              Start new chat
            </button>
          </div>
          <ChatPane
            ref={paneRef}
            conversation={selectedConversation}
            onSend={(content) => selectedConversation && sendMessage(selectedConversation.id, content)}
            onEditMessage={(messageId, content) => selectedConversation && editMessage(selectedConversation.id, messageId, content)}
            onResendMessage={(messageId) => selectedConversation && resendMessage(selectedConversation.id, messageId)}
            isThinking={isThinking && thinkingId === selectedConversation?.id}
            onPauseThinking={() => setIsThinking(false)}
            assistantThinkingLabel="AI doctor is responding..."
          />
        </div>
      </div>
    </div>
  )
}

