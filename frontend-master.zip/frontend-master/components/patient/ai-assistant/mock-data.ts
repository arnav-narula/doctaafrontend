import type { Conversation } from "@/components/doctor/ai-assistant/types"
import { makeId } from "@/components/doctor/ai-assistant/utils"

const now = Date.now()

export const PATIENT_INITIAL_CONVERSATIONS: Conversation[] = [
  {
    id: "p1",
    title: "Migraine check-in",
    consultBooked: false,
    updatedAt: new Date(now - 20 * 60 * 1000).toISOString(),
    messageCount: 6,
    preview: "Tracking triggers and whether to adjust my meds tonight...",
    pinned: true,
    folder: "Headache care",
    messages: [
      {
        id: makeId("pm"),
        role: "user",
        content: "I'm getting a migraine aura—should I take my triptan now?",
        createdAt: new Date(now - 21 * 60 * 1000).toISOString(),
      },
      {
        id: makeId("pm"),
        role: "assistant",
        content:
          "Take your triptan at the first sign of aura. Hydrate and rest in a dark room. Avoid a second dose within 24 hours unless advised.",
        createdAt: new Date(now - 20 * 60 * 1000).toISOString(),
      },
    ],
  },
  {
    id: "p2",
    title: "Cold and cough triage",
    consultBooked: true,
    updatedAt: new Date(now - 55 * 60 * 1000).toISOString(),
    messageCount: 4,
    preview: "Need to know if I should see urgent care for this cough...",
    pinned: false,
    folder: "Respiratory",
    messages: [],
  },
  {
    id: "p3",
    title: "Workout recovery tips",
    consultBooked: false,
    updatedAt: new Date(now - 3 * 60 * 60 * 1000).toISOString(),
    messageCount: 3,
    preview: "Sore knees after running—looking for safe stretches...",
    pinned: false,
    folder: "Fitness",
    messages: [],
  },
  {
    id: "p4",
    title: "Sleep routine check",
    consultBooked: true,
    updatedAt: new Date(now - 9 * 60 * 60 * 1000).toISOString(),
    messageCount: 5,
    preview: "Improving sleep while on new medication...",
    pinned: false,
    folder: "Wellness",
    messages: [],
  },
  {
    id: "p5",
    title: "Nutrition guidance",
    consultBooked: false,
    updatedAt: new Date(now - 30 * 60 * 60 * 1000).toISOString(),
    messageCount: 2,
    preview: "Balancing protein and carbs with my workout plan...",
    pinned: false,
    folder: "Nutrition",
    messages: [],
  },
]

