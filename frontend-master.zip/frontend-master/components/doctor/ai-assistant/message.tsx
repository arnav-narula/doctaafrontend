"use client"

import { cn } from "@/lib/utils"
import type { MessageRole } from "./types"

type MessageProps = {
  role: MessageRole
  children: React.ReactNode
  actions?: React.ReactNode
}

export function Message({ role, children, actions }: MessageProps) {
  const isUser = role === "user"

  return (
    <div className={cn("group flex flex-col gap-2", isUser ? "items-end" : "items-start")}>
      <div className={cn("flex gap-3", isUser ? "justify-end" : "justify-start")}>
        <div
          className={cn(
            "max-w-[75%] break-words rounded-2xl px-4 py-3 shadow-sm transition-shadow",
            isUser
              ? "rounded-br-md bg-muted text-foreground"
              : "rounded-bl-md border border-border/60 bg-card text-foreground",
          )}
        >
          {children}
        </div>
      </div>
      {actions ? (
        <div
          className={cn(
            "flex flex-wrap gap-2 text-xs text-muted-foreground/80 opacity-0 pointer-events-none transition-opacity duration-150 group-hover:opacity-100 group-hover:pointer-events-auto",
            isUser ? "justify-end" : "justify-start",
          )}
        >
          {actions}
        </div>
      ) : null}
    </div>
  )
}
