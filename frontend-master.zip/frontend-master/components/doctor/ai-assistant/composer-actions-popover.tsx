"use client"

import { useState } from "react"
import {
  BookOpen,
  Bot,
  ChevronRight,
  Globe,
  MoreHorizontal,
  Palette,
  Paperclip,
  Search,
} from "lucide-react"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import type { ComponentType } from "react"
import { cn } from "@/lib/utils"

type IconComponent = ComponentType<{ className?: string }>

type Action = {
  icon: IconComponent
  label: string
  badge?: string
  action: () => void
}

type ComposerActionsPopoverProps = {
  children: React.ReactNode
}

const GoogleDriveIcon: IconComponent = ({ className }) => (
  <div className={cn("flex h-4 w-4 items-center justify-center rounded bg-gradient-to-br from-blue-500 to-green-500", className)}>
    <div className="h-2 w-2 rounded-full bg-white" />
  </div>
)

const OneDriveIcon: IconComponent = ({ className }) => (
  <div className={cn("flex h-4 w-4 items-center justify-center rounded bg-gradient-to-br from-blue-600 to-blue-400", className)}>
    <div className="h-2 w-2 rounded-full bg-white" />
  </div>
)

const SharePointIcon: IconComponent = ({ className }) => (
  <div className={cn("flex h-4 w-4 items-center justify-center rounded bg-gradient-to-br from-teal-500 to-teal-400", className)}>
    <div className="h-2 w-2 rounded-full bg-white" />
  </div>
)

export function ComposerActionsPopover({ children }: ComposerActionsPopoverProps) {
  const [open, setOpen] = useState(false)
  const [showMore, setShowMore] = useState(false)

  const mainActions: Action[] = [
    { icon: Paperclip, label: "Add photos & files", action: () => console.log("Add photos & files") },
    { icon: Bot, label: "Agent mode", badge: "NEW", action: () => console.log("Agent mode") },
    { icon: Search, label: "Deep research", action: () => console.log("Deep research") },
    { icon: Palette, label: "Create image", action: () => console.log("Create image") },
    { icon: BookOpen, label: "Study and learn", action: () => console.log("Study and learn") },
  ]

  const moreActions: Action[] = [
    { icon: Globe, label: "Web search", action: () => console.log("Web search") },
    { icon: Palette, label: "Canvas", action: () => console.log("Canvas") },
    { icon: GoogleDriveIcon, label: "Connect Google Drive", action: () => console.log("Connect Google Drive") },
    { icon: OneDriveIcon, label: "Connect OneDrive", action: () => console.log("Connect OneDrive") },
    { icon: SharePointIcon, label: "Connect Sharepoint", action: () => console.log("Connect Sharepoint") },
  ]

  const handleAction = (callback: () => void) => {
    callback()
    setOpen(false)
    setShowMore(false)
  }

  const handleOpenChange = (nextOpen: boolean) => {
    setOpen(nextOpen)
    if (!nextOpen) setShowMore(false)
  }

  return (
    <Popover open={open} onOpenChange={handleOpenChange}>
      <PopoverTrigger asChild>{children}</PopoverTrigger>
      <PopoverContent className="w-96 p-0" align="start" side="top">
        {!showMore ? (
          <div className="p-3">
            <div className="space-y-1">
              {mainActions.map((action) => {
                const IconComponent = action.icon
                return (
                  <button
                    key={action.label}
                    type="button"
                    onClick={() => handleAction(action.action)}
                    className="flex w-full items-center gap-3 rounded-lg p-2 text-left text-sm text-foreground hover:bg-muted"
                  >
                    <IconComponent className="h-4 w-4" />
                    <span>{action.label}</span>
                    {action.badge && (
                      <span className="ml-auto rounded-full bg-blue-100 px-2 py-0.5 text-xs font-semibold text-blue-700 dark:bg-blue-900/70 dark:text-blue-200">
                        {action.badge}
                      </span>
                    )}
                  </button>
                )
              })}
              <button
                type="button"
                onClick={() => setShowMore(true)}
                className="flex w-full items-center gap-3 rounded-lg border border-dashed border-border p-2 text-left text-sm text-foreground hover:bg-muted"
              >
                <MoreHorizontal className="h-4 w-4" />
                <span>More</span>
                <ChevronRight className="ml-auto h-4 w-4" />
              </button>
            </div>
          </div>
        ) : (
          <div className="flex">
            <div className="flex-1 border-r border-border p-3">
              <div className="space-y-1">
                {mainActions.map((action) => {
                  const IconComponent = action.icon
                  return (
                    <button
                      key={action.label}
                      type="button"
                      onClick={() => handleAction(action.action)}
                      className="flex w-full items-center gap-3 rounded-lg p-2 text-left text-sm text-foreground hover:bg-muted"
                    >
                      <IconComponent className="h-4 w-4" />
                      <span>{action.label}</span>
                      {action.badge && (
                        <span className="ml-auto rounded-full bg-blue-100 px-2 py-0.5 text-xs font-semibold text-blue-700 dark:bg-blue-900/70 dark:text-blue-200">
                          {action.badge}
                        </span>
                      )}
                    </button>
                  )
                })}
                <button
                  type="button"
                  onClick={() => setShowMore(true)}
                  className="flex w-full items-center gap-3 rounded-lg border border-dashed border-border p-2 text-left text-sm text-foreground hover:bg-muted"
                >
                  <MoreHorizontal className="h-4 w-4" />
                  <span>More</span>
                  <ChevronRight className="ml-auto h-4 w-4" />
                </button>
              </div>
            </div>
            <div className="flex-1 p-3">
              <div className="space-y-1">
                {moreActions.map((action) => {
                  const IconComponent = action.icon
                  return (
                    <button
                      key={action.label}
                      type="button"
                      onClick={() => handleAction(action.action)}
                      className="flex w-full items-center gap-3 rounded-lg p-2 text-left text-sm text-foreground hover:bg-muted"
                    >
                      <IconComponent className="h-4 w-4" />
                      <span>{action.label}</span>
                    </button>
                  )
                })}
              </div>
            </div>
          </div>
        )}
      </PopoverContent>
    </Popover>
  )
}

