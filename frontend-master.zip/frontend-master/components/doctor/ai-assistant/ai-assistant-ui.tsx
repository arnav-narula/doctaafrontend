"use client"

import { useCallback, useEffect, useRef, useState } from "react"
import { ChatPane, type ChatPaneHandle } from "./chat-pane"
import { ChatListView } from "./chat-list-view"
import { INITIAL_CONVERSATIONS } from "./mock-data"
import type { Conversation } from "./types"
import { DOCTOR_AI_ASSISTANT_NEW_CHAT_EVENT, DOCTOR_AI_ASSISTANT_BACK_TO_LIST_EVENT, DOCTOR_AI_ASSISTANT_UPDATE_TITLE_EVENT } from "@/lib/events"

const chatbots = [
  { name: "Healthcare Provider", icon: "🩺" },
  { name: "Dr. Sarah Mitchell", icon: "👩‍⚕️" },
  { name: "Nurse Specialist", icon: "🩹" },
  { name: "Medical Assistant", icon: "🧠" },
]

type ViewState = "list" | "chat"

export function AIAssistantUI() {
  const [conversations, setConversations] = useState<Conversation[]>(INITIAL_CONVERSATIONS)
  const [selectedId, setSelectedId] = useState<string | null>(null)
  const [selectedBot, setSelectedBot] = useState(chatbots[0]?.name ?? "Healthcare Provider")
  const [isThinking, setIsThinking] = useState(false)
  const [thinkingId, setThinkingId] = useState<string | null>(null)
  const [view, setView] = useState<ViewState>("list")
  const paneRef = useRef<ChatPaneHandle | null>(null)

  const selectedConversation = conversations.find((conversation) => conversation.id === selectedId) ?? null

  const createNewChat = useCallback(() => {
    const id = Math.random().toString(36).slice(2)
    const newConversation: Conversation = {
      id,
      title: "New consultation",
      updatedAt: new Date().toISOString(),
      messageCount: 0,
      preview: "Start your consultation...",
      pinned: false,
      folder: "Consultations",
      messages: [],
    }
    setConversations((prev) => [newConversation, ...prev])
    setSelectedId(id)
    setView("chat")
  }, [])

  useEffect(() => {
    const handler = (event: KeyboardEvent) => {
      if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "n") {
        event.preventDefault()
        createNewChat()
      }
    }
    window.addEventListener("keydown", handler)
    return () => window.removeEventListener("keydown", handler)
  }, [createNewChat])

  useEffect(() => {
    const handler = () => createNewChat()
    window.addEventListener(
      DOCTOR_AI_ASSISTANT_NEW_CHAT_EVENT as keyof WindowEventMap,
      handler as EventListener,
    )
    return () =>
      window.removeEventListener(
        DOCTOR_AI_ASSISTANT_NEW_CHAT_EVENT as keyof WindowEventMap,
        handler as EventListener,
      )
  }, [createNewChat])

  useEffect(() => {
    const handler = () => {
      setView("list")
      setSelectedId(null)
    }
    window.addEventListener(
      DOCTOR_AI_ASSISTANT_BACK_TO_LIST_EVENT as keyof WindowEventMap,
      handler as EventListener,
    )
    return () =>
      window.removeEventListener(
        DOCTOR_AI_ASSISTANT_BACK_TO_LIST_EVENT as keyof WindowEventMap,
        handler as EventListener,
      )
  }, [])

  useEffect(() => {
    if (view === "chat" && selectedConversation) {
      const displayTitle = selectedConversation.patientName
        ? `${selectedConversation.patientName} - ${selectedConversation.title}`
        : selectedConversation.title
      window.dispatchEvent(
        new CustomEvent(DOCTOR_AI_ASSISTANT_UPDATE_TITLE_EVENT, {
          detail: { title: displayTitle },
        }),
      )
    } else if (view === "list") {
      window.dispatchEvent(
        new CustomEvent(DOCTOR_AI_ASSISTANT_UPDATE_TITLE_EVENT, {
          detail: { title: null },
        }),
      )
    }
  }, [view, selectedConversation])

  const sendMessage = (conversationId: string, content: string) => {
    if (!content.trim()) return
    const now = new Date().toISOString()
    const userMessage = { id: Math.random().toString(36).slice(2), role: "user" as const, content, createdAt: now }

    setConversations((prev) =>
      prev.map((conversation) =>
        conversation.id === conversationId
          ? {
              ...conversation,
              messages: [...conversation.messages, userMessage],
              updatedAt: now,
              messageCount: conversation.messages.length + 1,
              preview: content.slice(0, 80),
            }
          : conversation,
      ),
    )

    setIsThinking(true)
    setThinkingId(conversationId)

    setTimeout(() => {
      setIsThinking(false)
      setThinkingId(null)
      setConversations((prev) =>
        prev.map((conversation) =>
          conversation.id === conversationId
            ? {
                ...conversation,
                messages: [
                  ...conversation.messages,
                  {
                    id: Math.random().toString(36).slice(2),
                    role: "assistant" as const,
                    content:
                      "Thank you for the update. I'll review the details you provided and follow up with next steps shortly.",
                    createdAt: new Date().toISOString(),
                  },
                ],
                updatedAt: new Date().toISOString(),
                messageCount: conversation.messages.length + 2,
                preview: "Thank you for the update...",
              }
            : conversation,
        ),
      )
    }, 2000)
  }

  const editMessage = (conversationId: string, messageId: string, newContent: string) => {
    setConversations((prev) =>
      prev.map((conversation) => {
        if (conversation.id !== conversationId) return conversation
        const updatedMessages = conversation.messages.map((message) =>
          message.id === messageId ? { ...message, content: newContent, editedAt: new Date().toISOString() } : message,
        )
        return {
          ...conversation,
          messages: updatedMessages,
          preview: updatedMessages.at(-1)?.content.slice(0, 80) ?? conversation.preview,
        }
      }),
    )
  }

  const resendMessage = (conversationId: string, messageId: string) => {
    const conversation = conversations.find((conv) => conv.id === conversationId)
    const message = conversation?.messages.find((msg) => msg.id === messageId)
    if (!conversation || !message) return

    const now = new Date().toISOString()

    // Trim any messages that come after the edited user message
    setConversations((prev) =>
      prev.map((conv) => {
        if (conv.id !== conversationId) return conv
        const messages = conv.messages ?? []
        const index = messages.findIndex((m) => m.id === messageId)
        if (index === -1) return conv
        const trimmed = messages.slice(0, index + 1)
        return {
          ...conv,
          messages: trimmed,
          updatedAt: now,
          messageCount: trimmed.length,
          preview: trimmed.at(-1)?.content.slice(0, 80) ?? conv.preview,
        }
      }),
    )

    setIsThinking(true)
    setThinkingId(conversationId)

    setTimeout(() => {
      setIsThinking(false)
      setThinkingId(null)
      setConversations((prev) =>
        prev.map((conv) => {
          if (conv.id !== conversationId) return conv
          const messages = conv.messages ?? []
          const assistantMessage = {
            id: Math.random().toString(36).slice(2),
            role: "assistant" as const,
            content:
              "Thank you for the update. I'll review the details you provided and follow up with next steps shortly.",
            createdAt: new Date().toISOString(),
          }
          return {
            ...conv,
            messages: [...messages, assistantMessage],
            updatedAt: new Date().toISOString(),
            messageCount: messages.length + 1,
            preview: "Thank you for the update...",
          }
        }),
      )
    }, 2000)
  }

  const togglePin = useCallback((conversationId: string) => {
    setConversations((prev) =>
      prev.map((conversation) =>
        conversation.id === conversationId ? { ...conversation, pinned: !conversation.pinned } : conversation,
      ),
    )
  }, [])

  if (view === "list") {
    return (
      <div className="flex h-full flex-1 flex-col overflow-hidden">
        <ChatListView
          conversations={conversations}
          onSelectChat={(id) => {
            setSelectedId(id)
            setView("chat")
          }}
          onCreateChat={createNewChat}
          onTogglePin={togglePin}
        />
      </div>
    )
  }

  return (
    <div className="flex h-full flex-1 flex-col overflow-hidden">
      <ChatPane
        ref={paneRef}
        conversation={selectedConversation}
        onSend={(content) => selectedConversation && sendMessage(selectedConversation.id, content)}
        onEditMessage={(messageId, content) => selectedConversation && editMessage(selectedConversation.id, messageId, content)}
        onResendMessage={(messageId) => selectedConversation && resendMessage(selectedConversation.id, messageId)}
        isThinking={isThinking && thinkingId === selectedConversation?.id}
        onPauseThinking={() => setIsThinking(false)}
      />
    </div>
  )
}

