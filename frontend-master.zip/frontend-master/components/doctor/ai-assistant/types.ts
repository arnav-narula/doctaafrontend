export type MessageRole = "user" | "assistant"

export interface ChatMessage {
  id: string
  role: MessageRole
  content: string
  createdAt: string
  editedAt?: string
}

export interface Conversation {
  id: string
  title: string
  patientName?: string
  updatedAt: string
  messageCount: number
  preview: string
  pinned: boolean
  folder: string
  messages: ChatMessage[]
  consultBooked?: boolean
}

