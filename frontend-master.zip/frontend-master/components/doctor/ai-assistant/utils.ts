export function timeAgo(date: string | number | Date) {
  const d = typeof date === "string" ? new Date(date) : new Date(date)
  const now = new Date()
  const seconds = Math.max(1, Math.floor((now.getTime() - d.getTime()) / 1000))

  const rtf = new Intl.RelativeTimeFormat(undefined, { numeric: "auto" })
  const ranges: Array<[number, Intl.RelativeTimeFormatUnit, number]> = [
    [60, "second", 1],
    [3600, "minute", 60],
    [86400, "hour", 3600],
    [604800, "day", 86400],
    [2629800, "week", 604800],
    [31557600, "month", 2629800],
  ]

  for (const [limit, unit, divisor] of ranges) {
    if (seconds < limit) {
      return rtf.format(-Math.floor(seconds / divisor), unit)
    }
  }

  return rtf.format(-Math.floor(seconds / 31557600), "year")
}

export function makeId(prefix: string) {
  return `${prefix}${Math.random().toString(36).slice(2, 10)}`
}