"use client"

import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react"
import { Check, Copy, Pencil, RefreshCw, Square, X } from "lucide-react"
import { cn } from "@/lib/utils"
import type { Conversation } from "./types"
import { Message } from "./message"
import { Composer, type ComposerHandle } from "./composer"
import { timeAgo } from "./utils"

type ChatPaneProps = {
  conversation: Conversation | null
  onSend?: (content: string) => Promise<void> | void
  onEditMessage?: (messageId: string, newContent: string) => void
  onResendMessage?: (messageId: string) => void
  isThinking?: boolean
  onPauseThinking?: () => void
  assistantThinkingLabel?: string
}

export type ChatPaneHandle = {
  insertTemplate: (template: string) => void
}

export const ChatPane = forwardRef<ChatPaneHandle, ChatPaneProps>(function ChatPane(
  {
    conversation,
    onSend,
    onEditMessage,
    onResendMessage,
    isThinking,
    onPauseThinking,
    assistantThinkingLabel = "Healthcare provider is responding...",
  },
  ref,
) {
  const [editingId, setEditingId] = useState<string | null>(null)
  const [draft, setDraft] = useState("")
  const [busy, setBusy] = useState(false)
  const [copiedId, setCopiedId] = useState<string | null>(null)
  const composerRef = useRef<ComposerHandle | null>(null)
  const scrollContainerRef = useRef<HTMLDivElement | null>(null)
  const copyResetRef = useRef<NodeJS.Timeout | null>(null)

  useImperativeHandle(
    ref,
    () => ({
      insertTemplate: (template: string) => composerRef.current?.insertTemplate(template),
    }),
    [],
  )

  const messages = conversation?.messages ?? []

  // Always show the latest messages by scrolling to the bottom when content changes
  useEffect(() => {
    const container = scrollContainerRef.current
    if (!container) return
    container.scrollTop = container.scrollHeight
  }, [messages.length, isThinking])

  if (!conversation) {
    return (
      <div className="flex flex-1 items-center justify-center text-muted-foreground">
        Select a consultation to begin.
      </div>
    )
  }

  const handleSave = () => {
    if (!editingId) return
    onEditMessage?.(editingId, draft)
    setEditingId(null)
    setDraft("")
  }

  const handleSaveAndResend = () => {
    if (!editingId) return
    onEditMessage?.(editingId, draft)
    onResendMessage?.(editingId)
    setEditingId(null)
    setDraft("")
  }

  const handleCopy = async (messageId: string, content: string) => {
    try {
      await navigator.clipboard?.writeText(content)
      if (copyResetRef.current) {
        clearTimeout(copyResetRef.current)
      }
      setCopiedId(messageId)
      copyResetRef.current = setTimeout(() => {
        setCopiedId(null)
      }, 1000)
    } catch (error) {
      console.error("Failed to copy message", error)
    }
  }

  useEffect(() => {
    return () => {
      if (copyResetRef.current) {
        clearTimeout(copyResetRef.current)
      }
    }
  }, [])

  return (
    <div className="flex h-full min-h-0 flex-1 flex-col bg-background">
      <div ref={scrollContainerRef} className="flex-1 overflow-y-auto">
        <div className="mx-auto flex h-full w-full max-w-4xl flex-col gap-5 px-4 py-6">
          {messages.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border/60 bg-muted/20 p-8 text-center">
              <p className="text-sm text-muted-foreground">Send your first message to begin the consultation.</p>
            </div>
          ) : (
            <>
              {messages.map((message) => (
                <div key={message.id} className="space-y-2">
                  {editingId === message.id ? (
                    <div className="rounded-3xl bg-muted px-4 py-3 shadow-sm">
                      <textarea
                        value={draft}
                        onChange={(event) => setDraft(event.target.value)}
                        className="w-full resize-none rounded-2xl bg-transparent px-1 py-1 text-base text-foreground outline-none focus-visible:ring-0"
                        rows={2}
                      />
                      <div className="mt-3 flex items-center justify-end gap-2">
                        <button
                          type="button"
                          onClick={() => {
                            setEditingId(null)
                            setDraft("")
                          }}
                          className="inline-flex items-center gap-2 rounded-full border border-border/60 bg-background px-4 py-2 text-sm text-foreground transition hover:bg-muted/70"
                        >
                          Cancel
                        </button>
                        <button
                          type="button"
                          onClick={handleSaveAndResend}
                          className="inline-flex items-center gap-2 rounded-full bg-foreground px-5 py-2 text-sm text-background transition hover:bg-foreground/90"
                        >
                          Send
                        </button>
                      </div>
                    </div>
                  ) : (
                  <Message
                    role={message.role}
                    actions={
                      message.role === "user" ? (
                        <div className="flex items-center gap-1">
                          <button
                            type="button"
                            className="inline-flex size-7 items-center justify-center rounded-md p-1.5 text-muted-foreground/80 transition hover:bg-muted/60 hover:text-foreground"
                            onClick={() => handleCopy(message.id, message.content)}
                            aria-label={copiedId === message.id ? "Copied" : "Copy message"}
                          >
                            {copiedId === message.id ? (
                              <Check className="h-3.5 w-3.5 text-blue-600" />
                            ) : (
                              <Copy className="h-3.5 w-3.5" />
                            )}
                          </button>
                          <button
                            type="button"
                            className="inline-flex size-7 items-center justify-center rounded-md p-1.5 text-muted-foreground/80 transition hover:bg-muted/60 hover:text-foreground"
                            onClick={() => {
                              setEditingId(message.id)
                              setDraft(message.content)
                            }}
                            aria-label="Edit message"
                          >
                            <Pencil className="h-3.5 w-3.5" />
                          </button>
                        </div>
                      ) : undefined
                    }
                  >
                    <div className="whitespace-pre-wrap leading-relaxed text-sm" style={{ overflowWrap: 'break-word', wordBreak: 'normal' }}>{message.content}</div>
                  </Message>
                )}
                </div>
              ))}
              {isThinking && (
                <Message role="assistant">
                  <div className="flex items-center gap-3">
                    <div className="flex items-center gap-1">
                    <span className="h-2 w-2 animate-bounce rounded-full bg-primary/70 [animation-delay:-0.3s]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-primary/70 [animation-delay:-0.15s]" />
                    <span className="h-2 w-2 animate-bounce rounded-full bg-primary/70" />
                    </div>
                  <span className="text-sm text-muted-foreground">{assistantThinkingLabel}</span>
                    <button
                      type="button"
                      onClick={onPauseThinking}
                      className="ml-auto inline-flex items-center gap-1.5 rounded-full border border-border/60 bg-background px-3 py-1 text-xs text-muted-foreground transition-all hover:bg-muted/50"
                    >
                      <Square className="h-3 w-3" /> Pause
                    </button>
                  </div>
                </Message>
              )}
            </>
          )}
        </div>
      </div>

      <Composer
        ref={composerRef}
        busy={busy}
        onSend={async (text) => {
          if (!text.trim()) return
          setBusy(true)
          await onSend?.(text)
          setBusy(false)
        }}
      />
    </div>
  )
})

