"use client"

import { endOfDay, format, formatDistanceToNow, startOfDay } from "date-fns"
import { Calendar as CalendarIcon, MessageCircle, Pin, Plus, Search } from "lucide-react"
import { useMemo, useState } from "react"
import type { DateRange } from "react-day-picker"
import type { Conversation } from "./types"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"

type ChatListViewProps = {
  conversations: Conversation[]
  onSelectChat: (id: string) => void
  onCreateChat: () => void
  onTogglePin: (id: string) => void
  consultCtaLabel?: string
  onBookConsult?: (conversation: Conversation) => void
}

export function ChatListView({
  conversations,
  onSelectChat,
  onCreateChat,
  onTogglePin,
  consultCtaLabel,
  onBookConsult,
}: ChatListViewProps) {
  const [searchQuery, setSearchQuery] = useState("")
  const [dateRange, setDateRange] = useState<DateRange | undefined>()

  const filteredConversations = useMemo(() => {
    const search = searchQuery.trim().toLowerCase()
    return conversations.filter((conversation) => {
      const displayTitle = conversation.patientName
        ? `${conversation.patientName} - ${conversation.title}`
        : conversation.title
      const matchesSearch =
        !search ||
        displayTitle.toLowerCase().includes(search) ||
        conversation.title.toLowerCase().includes(search) ||
        conversation.patientName?.toLowerCase().includes(search) ||
        conversation.preview.toLowerCase().includes(search) ||
        conversation.folder.toLowerCase().includes(search)

      const updatedAt = new Date(conversation.updatedAt)
      const matchesDate =
        (!dateRange?.from || updatedAt >= startOfDay(dateRange.from)) &&
        (!dateRange?.to || updatedAt <= endOfDay(dateRange.to))

      return matchesSearch && matchesDate
    })
  }, [conversations, dateRange, searchQuery])

  const pinned = useMemo(
    () => filteredConversations.filter((conversation) => conversation.pinned),
    [filteredConversations],
  )
  const recent = useMemo(
    () =>
      filteredConversations
        .filter((conversation) => !conversation.pinned)
        .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime()),
    [filteredConversations],
  )
  const hasConversations = filteredConversations.length > 0
  const dateLabel = useMemo(() => {
    if (dateRange?.from && dateRange?.to) {
      return `${format(dateRange.from, "MMM d")} → ${format(dateRange.to, "MMM d")}`
    }
    if (dateRange?.from) {
      return format(dateRange.from, "MMM d, yyyy")
    }
    return "All dates"
  }, [dateRange])

  return (
    <div className="flex h-full flex-1 flex-col bg-background text-foreground">
      <div className="px-6 py-4">
        <div className="flex flex-col gap-3 lg:flex-row lg:items-center lg:justify-between">
          <div className="relative w-full lg:w-[360px]">
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <Input
              value={searchQuery}
              onChange={(event) => setSearchQuery(event.target.value)}
              placeholder="Search consultations"
              className="rounded-full pl-9"
            />
          </div>
          <div className="flex flex-wrap items-center gap-2">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="gap-2 rounded-full px-4 text-left text-sm font-normal"
                >
                  <CalendarIcon className="h-4 w-4" />
                  {dateLabel}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="end">
                <Calendar
                  initialFocus
                  mode="range"
                  numberOfMonths={2}
                  selected={dateRange}
                  onSelect={setDateRange}
                />
                <div className="flex items-center justify-between border-t p-2">
                  <Button variant="ghost" size="sm" onClick={() => setDateRange(undefined)}>
                    Clear
                  </Button>
                  {dateRange?.from && dateRange?.to ? (
                    <p className="text-xs text-muted-foreground">
                      {format(dateRange.from, "MMM d")} → {format(dateRange.to, "MMM d")}
                    </p>
                  ) : (
                    <p className="text-xs text-muted-foreground">Select from & to</p>
                  )}
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>
      </div>

      <div className="flex-1 overflow-hidden">
        <div className="queue-scroll h-full overflow-y-auto px-6 py-3 pr-1">
          {pinned.length > 0 && (
            <section className="mb-4">
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Pinned</p>
              <div className="space-y-1">
                {pinned.map((conversation) => (
                  <ChatListRow
                    key={conversation.id}
                    chat={conversation}
                    onSelect={onSelectChat}
                    onTogglePin={onTogglePin}
                    showInlinePin={false}
                    consultCtaLabel={consultCtaLabel}
                    onBookConsult={onBookConsult}
                  />
                ))}
              </div>
            </section>
          )}

          {recent.length > 0 && (
            <section>
              <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-muted-foreground">Recent</p>
              <div className="space-y-1">
                {recent.map((conversation) => (
                  <ChatListRow
                    key={conversation.id}
                    chat={conversation}
                    onSelect={onSelectChat}
                    onTogglePin={onTogglePin}
                    showInlinePin
                    consultCtaLabel={consultCtaLabel}
                    onBookConsult={onBookConsult}
                  />
                ))}
              </div>
            </section>
          )}

          {!hasConversations && (
            <div className="flex flex-col items-center justify-center py-12 text-center text-muted-foreground">
              <MessageCircle className="mb-3 h-8 w-8" />
              <p className="font-semibold text-foreground">No consultations found</p>
              <p className="mb-4 text-sm">Start a new consultation to begin.</p>
              <button
                type="button"
                onClick={onCreateChat}
                className="inline-flex items-center gap-2 rounded-lg bg-foreground px-4 py-2 text-sm font-medium text-background transition hover:bg-foreground/90"
              >
                <Plus className="h-4 w-4" />
                Start
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}

type ChatListRowProps = {
  chat: Conversation
  onSelect: (id: string) => void
  onTogglePin: (id: string) => void
  showInlinePin?: boolean
  consultCtaLabel?: string
  onBookConsult?: (conversation: Conversation) => void
}

function ChatListRow({ chat, onSelect, onTogglePin, showInlinePin, consultCtaLabel, onBookConsult }: ChatListRowProps) {
  const displayTitle = chat.patientName ? `${chat.patientName} - ${chat.title}` : chat.title
  const consultBooked = chat.consultBooked === true

  return (
    <div className="group flex w-full items-center gap-3 rounded-lg px-3 py-2 transition hover:bg-muted">
      <button
        type="button"
        onClick={() => onSelect(chat.id)}
        className="min-w-0 flex-1 text-left"
      >
        <div className="flex items-center gap-2">
          <p className="truncate text-sm font-medium text-foreground">{displayTitle}</p>
          <button
            type="button"
            onClick={(e) => {
              e.stopPropagation()
              onTogglePin(chat.id)
            }}
            className="inline-flex h-5 w-5 shrink-0 items-center justify-center rounded-full text-muted-foreground transition hover:bg-muted/70"
            aria-label={chat.pinned ? "Unpin conversation" : "Pin conversation"}
          >
            <Pin className="h-3.5 w-3.5" fill={chat.pinned ? "currentColor" : "none"} />
          </button>
        </div>
        <p className="mt-0.5 line-clamp-1 text-xs text-muted-foreground">{chat.preview}</p>
      </button>
      <div className="flex min-w-[170px] flex-col items-end gap-1 text-right">
        <span className="text-xs text-muted-foreground">
          {formatDistanceToNow(new Date(chat.updatedAt), { addSuffix: true })}
        </span>
        {consultBooked ? (
          <span className="rounded-full bg-emerald-50 px-3 py-1 text-xs font-medium text-emerald-700 ring-1 ring-emerald-100">
            Consult booked
          </span>
        ) : onBookConsult ? (
          <button
            type="button"
            onClick={(event) => {
              event.stopPropagation()
              onBookConsult(chat)
            }}
            className="inline-flex items-center gap-1 rounded-full bg-foreground px-3 py-1 text-xs font-medium text-background transition hover:bg-foreground/90"
          >
            {consultCtaLabel ?? "Book consult ($49)"}
          </button>
        ) : null}
      </div>
    </div>
  )
}

