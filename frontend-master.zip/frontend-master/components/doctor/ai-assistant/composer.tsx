"use client"

import { forwardRef, useEffect, useImperativeHandle, useRef, useState } from "react"
import { ArrowUp, Loader2, Mic, Plus } from "lucide-react"
import { cn } from "@/lib/utils"
import { ComposerActionsPopover } from "./composer-actions-popover"

export type ComposerHandle = {
  insertTemplate: (template: string) => void
  focus: () => void
}

type ComposerProps = {
  onSend?: (message: string) => Promise<void> | void
  busy?: boolean
}

export const Composer = forwardRef<ComposerHandle, ComposerProps>(function Composer({ onSend, busy }, ref) {
  const [value, setValue] = useState("")
  const [sending, setSending] = useState(false)
  const [lineCount, setLineCount] = useState(1)
  const inputRef = useRef<HTMLTextAreaElement | null>(null)

  useEffect(() => {
    const textarea = inputRef.current
    if (!textarea) return
    const lineHeight = 20
    const minHeight = 32
    const maxLines = 4
    const maxHeight = minHeight + (maxLines - 1) * lineHeight

    textarea.style.height = "auto"
    const scrollHeight = textarea.scrollHeight
    const calculatedLines = Math.max(1, Math.floor((scrollHeight - 16) / lineHeight))
    setLineCount(calculatedLines)

    if (calculatedLines <= maxLines) {
      textarea.style.height = `${Math.max(minHeight, scrollHeight)}px`
      textarea.style.overflowY = "hidden"
    } else {
      textarea.style.height = `${maxHeight}px`
      textarea.style.overflowY = "auto"
    }
  }, [value])

  useImperativeHandle(
    ref,
    () => ({
      insertTemplate: (templateContent: string) => {
        setValue((prev) => {
          const nextValue = prev ? `${prev}\n\n${templateContent}` : templateContent
          queueMicrotask(() => {
            if (!inputRef.current) return
            inputRef.current.focus()
            const length = nextValue.length
            inputRef.current.setSelectionRange(length, length)
          })
          return nextValue
        })
      },
      focus: () => inputRef.current?.focus(),
    }),
    [],
  )

  const handleSend = async () => {
    if (!value.trim() || sending) return
    setSending(true)
    try {
      await onSend?.(value)
      setValue("")
      inputRef.current?.focus()
    } finally {
      setSending(false)
    }
  }

  return (
    <div className="bg-background/95 p-4 backdrop-blur-sm supports-[backdrop-filter]:bg-background/80">
      <div className="mx-auto flex w-full max-w-4xl items-center gap-2 rounded-full border border-border/60 bg-background px-4 py-2 shadow-sm transition-all focus-within:border-border focus-within:shadow-md">
        <ComposerActionsPopover>
          <button
            type="button"
            className="inline-flex h-6 w-6 shrink-0 items-center justify-center text-foreground transition-colors hover:opacity-70"
          >
            <Plus className="h-4 w-4" />
          </button>
        </ComposerActionsPopover>

        <textarea
          ref={inputRef}
          value={value}
          onChange={(event) => setValue(event.target.value)}
          placeholder="Ask anything"
          rows={1}
          className={cn(
            "min-h-[32px] flex-1 resize-none bg-transparent px-0 py-1.5 text-left text-sm leading-relaxed text-foreground outline-none placeholder:text-muted-foreground/60 chat-input-scroll",
          )}
          style={{ height: "auto", overflowY: lineCount > 4 ? "auto" : "hidden" }}
          onKeyDown={(event) => {
            if (event.key === "Enter" && !event.shiftKey) {
              event.preventDefault()
              handleSend()
            }
          }}
        />

        <div className="flex shrink-0 items-center gap-2">
          <button
            type="button"
            className="inline-flex h-6 w-6 items-center justify-center text-foreground transition-colors hover:opacity-70"
            title="Voice input"
          >
            <Mic className="h-4 w-4" />
          </button>

          <button
            type="button"
            onClick={handleSend}
            disabled={sending || busy || !value.trim()}
            className={cn(
              "inline-flex h-8 w-8 items-center justify-center rounded-full bg-foreground text-background transition-all focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20 disabled:cursor-not-allowed disabled:opacity-50 hover:bg-foreground/90",
            )}
          >
            {sending || busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowUp className="h-4 w-4" />}
          </button>
        </div>
      </div>
    </div>
  )
})

