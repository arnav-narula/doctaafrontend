'use client'

import { useRef, useEffect, useState } from 'react'
import FullCalendar from '@fullcalendar/react'
import dayGridPlugin from '@fullcalendar/daygrid'
import timeGridPlugin from '@fullcalendar/timegrid'
import interactionPlugin from '@fullcalendar/interaction'
import type { EventInput, DateSelectArg, EventClickArg } from '@fullcalendar/core'
import enGbLocale from '@fullcalendar/core/locales/en-gb.js'
import { cn } from '@/lib/utils'

interface FullCalendarComponentProps {
  events: EventInput[]
  initialView?: 'timeGridWeek' | 'timeGridDay'
  height?: string | number
  className?: string
  onDateSelect?: (selectInfo: DateSelectArg) => void
  onEventClick?: (clickInfo: EventClickArg) => void
}

export function FullCalendarComponent({
  events,
  initialView = 'timeGridWeek',
  height = 'auto',
  className,
  onDateSelect,
  onEventClick,
}: FullCalendarComponentProps) {
  const calendarRef = useRef<FullCalendar>(null)
  
  // Get current local time as state to ensure nowIndicator uses correct time
  const [currentTime, setCurrentTime] = useState(() => {
    const now = new Date()
    const year = now.getFullYear()
    const month = String(now.getMonth() + 1).padStart(2, '0')
    const day = String(now.getDate()).padStart(2, '0')
    const hours = String(now.getHours()).padStart(2, '0')
    const minutes = String(now.getMinutes()).padStart(2, '0')
    const seconds = String(now.getSeconds()).padStart(2, '0')
    return `${year}-${month}-${day}T${hours}:${minutes}:${seconds}`
  })
  
  // Update current time every minute to keep nowIndicator accurate
  useEffect(() => {
    const interval = setInterval(() => {
      const now = new Date()
      const year = now.getFullYear()
      const month = String(now.getMonth() + 1).padStart(2, '0')
      const day = String(now.getDate()).padStart(2, '0')
      const hours = String(now.getHours()).padStart(2, '0')
      const minutes = String(now.getMinutes()).padStart(2, '0')
      const seconds = String(now.getSeconds()).padStart(2, '0')
      setCurrentTime(`${year}-${month}-${day}T${hours}:${minutes}:${seconds}`)
    }, 60000) // Update every minute
    
    return () => clearInterval(interval)
  }, [])
  
  // Get today's date at midnight (local time)
  const today = new Date()
  const todayYear = today.getFullYear()
  const todayMonth = today.getMonth()
  const todayDay = today.getDate()
  const todayDate = new Date(todayYear, todayMonth, todayDay, 0, 0, 0, 0)
  
  // Calculate date exactly 3 days before today for centered view
  // Format: YYYY-MM-DD to avoid timezone issues
  const startDate = new Date(todayYear, todayMonth, todayDay - 3, 0, 0, 0, 0)
  const startDateStr = `${startDate.getFullYear()}-${String(startDate.getMonth() + 1).padStart(2, '0')}-${String(startDate.getDate()).padStart(2, '0')}`

  // Calculate current time for scrollTime (using local time)
  const getCurrentTime = () => {
    const now = new Date()
    // Use local time methods
    const hours = now.getHours() // Already local time
    const minutes = now.getMinutes() // Already local time
    return `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00`
  }

  // Scroll to current time after calendar renders
  useEffect(() => {
    const scrollToCurrentTime = () => {
      if (calendarRef.current) {
        try {
          const calendarApi = calendarRef.current.getApi()
          const now = new Date()
          const hours = now.getHours() // Local time
          const minutes = now.getMinutes() // Local time
          const currentTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00`
          console.log('Scrolling to current time:', currentTime, 'Current hour:', hours)
          
          // Try using the scroll method directly
          const timeGridEl = document.querySelector('.fc-timeGrid-body') as HTMLElement
          if (timeGridEl) {
            const slotHeight = 2.25 * 16 // 2.25em in pixels (assuming 16px base)
            const totalSlots = hours * 2 + Math.floor(minutes / 30) // 30-minute slots
            const scrollPosition = totalSlots * slotHeight
            timeGridEl.scrollTop = scrollPosition
            console.log('Direct scroll to position:', scrollPosition, 'for time:', currentTime)
          }
          
          // Also try the API method
          calendarApi.scrollToTime(currentTime)
        } catch (error) {
          console.error('Error scrolling to current time:', error)
        }
      }
    }
    
    // Try multiple times with increasing delays to ensure calendar is fully rendered
    const timeout1 = setTimeout(scrollToCurrentTime, 100)
    const timeout2 = setTimeout(scrollToCurrentTime, 300)
    const timeout3 = setTimeout(scrollToCurrentTime, 500)
    const timeout4 = setTimeout(scrollToCurrentTime, 1000)
    
    return () => {
      clearTimeout(timeout1)
      clearTimeout(timeout2)
      clearTimeout(timeout3)
      clearTimeout(timeout4)
    }
  }, [])

  // Helper function to format time as "11am", "12pm", "1pm"
  const formatTime = (date: Date): string => {
    const hour = date.getHours()
    const minute = date.getMinutes()
    const period = hour >= 12 ? 'pm' : 'am'
    const displayHour = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour
    return minute === 0 ? `${displayHour}${period}` : `${displayHour}:${minute.toString().padStart(2, '0')}${period}`
  }

  return (
    <div className={cn('fullcalendar-wrapper', className)}>
      <FullCalendar
        ref={calendarRef}
        plugins={[dayGridPlugin, timeGridPlugin, interactionPlugin]}
        locale={enGbLocale}
        timeZone="local"
        firstDay={1}
        now={currentTime}
        initialDate={initialView === 'timeGridWeek' ? startDateStr : todayDate.toISOString().split('T')[0]}
        initialView={initialView}
        events={events}
        height={height}
        headerToolbar={{
          left: 'prev,next today',
          center: 'title',
          right: 'timeGridWeek,timeGridDay',
        }}
                views={{
                  timeGridWeek: {
                    duration: { days: 7 },
                    slotMinTime: "00:00:00",
                    slotMaxTime: "24:00:00",
                    buttonText: 'Week',
                  },
          timeGridDay: {
            slotMinTime: "00:00:00",
            slotMaxTime: "24:00:00",
            buttonText: 'Day',
          },
        }}
        buttonText={{
          today: 'Today',
          prev: '←',
          next: '→',
        }}
        selectable={!!onDateSelect}
        selectMirror={true}
        dayMaxEvents={true}
        weekends={true}
        select={onDateSelect}
        eventClick={onEventClick}
        eventDisplay="block"
        eventTimeFormat={(info) => {
          try {
            // FullCalendar v6: info.date might be ExpandedZonedMarker
            const dateValue = info.date as any
            
            // Try to get the date - ExpandedZonedMarker might have toDate() or similar
            let date: Date
            if (dateValue instanceof Date) {
              date = dateValue
            } else if (dateValue?.toDate && typeof dateValue.toDate === 'function') {
              date = dateValue.toDate()
            } else if (dateValue?.date instanceof Date) {
              date = dateValue.date
            } else if (typeof dateValue === 'string') {
              date = new Date(dateValue)
            } else if (dateValue?.marker) {
              // Try accessing marker property
              date = new Date(dateValue.marker)
            } else {
              // Last resort: try to convert to string then to date
              const dateStr = String(dateValue)
              date = new Date(dateStr)
            }
            
            // Validate date
            if (!date || isNaN(date.getTime())) {
              return ''
            }
            
            return formatTime(date)
          } catch (e) {
            console.error('Error formatting event time:', e, info)
            return ''
          }
        }}
        slotLabelFormat={(info) => {
          try {
            // FullCalendar v6: info.date might be ExpandedZonedMarker
            const dateValue = info.date as any
            
            // Try to get the date - ExpandedZonedMarker might have toDate() or similar
            let date: Date
            if (dateValue instanceof Date) {
              date = dateValue
            } else if (dateValue?.toDate && typeof dateValue.toDate === 'function') {
              date = dateValue.toDate()
            } else if (dateValue?.date instanceof Date) {
              date = dateValue.date
            } else if (typeof dateValue === 'string') {
              date = new Date(dateValue)
            } else if (dateValue?.marker) {
              // Try accessing marker property
              date = new Date(dateValue.marker)
            } else {
              // Last resort: try to convert to string then to date
              const dateStr = String(dateValue)
              date = new Date(dateStr)
            }
            
            // Validate date
            if (!date || isNaN(date.getTime())) {
              return ''
            }
            
            return formatTime(date)
          } catch (e) {
            console.error('Error formatting slot time:', e, info)
            return ''
          }
        }}
        slotMinTime="00:00:00"
        slotMaxTime="24:00:00"
        slotDuration="00:30:00"
        allDaySlot={false}
        nowIndicator={true}
        scrollTime={getCurrentTime()}
        datesSet={(arg) => {
          // Scroll to current time when dates are set
          setTimeout(() => {
            const now = new Date()
            const hours = now.getHours() // Local time
            const minutes = now.getMinutes() // Local time
            const currentTime = `${String(hours).padStart(2, '0')}:${String(minutes).padStart(2, '0')}:00`
            console.log('datesSet - Scrolling to current time:', currentTime, 'Current hour:', hours)
            if (calendarRef.current) {
              try {
                const calendarApi = calendarRef.current.getApi()
                
                // Try direct DOM scroll first
                const timeGridEl = document.querySelector('.fc-timeGrid-body') as HTMLElement
                if (timeGridEl) {
                  const slotHeight = 2.25 * 16 // 2.25em in pixels
                  const totalSlots = hours * 2 + Math.floor(minutes / 30)
                  const scrollPosition = totalSlots * slotHeight
                  timeGridEl.scrollTop = scrollPosition
                  console.log('datesSet - Direct scroll to position:', scrollPosition)
                }
                
                // Also try the API method
                calendarApi.scrollToTime(currentTime)
              } catch (error) {
                console.error('Error scrolling to current time in datesSet:', error)
              }
            }
          }, 50)
        }}
        dayHeaderFormat={{
          weekday: 'short',
          day: '2-digit',
          month: '2-digit',
        }}
      />
    </div>
  )
}

