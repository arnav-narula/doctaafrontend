'use client'

import { useEffect, useState } from "react"
import type { ReactNode } from "react"
import Link from "next/link"
import { IconArrowLeft, IconPlus } from "@tabler/icons-react"
import { SidebarTrigger } from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { useSelectedLayoutSegments } from "next/navigation"
import { DOCTOR_AI_ASSISTANT_NEW_CHAT_EVENT, DOCTOR_AI_ASSISTANT_BACK_TO_LIST_EVENT, DOCTOR_AI_ASSISTANT_UPDATE_TITLE_EVENT } from "@/lib/events"

const TITLE_MAP: Record<string, string> = {
  doctor: "Dashboard",
  "doctor/consultations": "Consultations",
  "doctor/patients": "Patients",
  "doctor/ai-assistant": "AI Assistant",
  "doctor/prescriptions": "Prescriptions",
  patient: "", // Will be set dynamically to "Welcome back [name]!"
  "patient/ai-chat": "AI Doctor",
  "patient/appointments": "Appointments",
  "patient/consultation-history": "Consultation History",
  "patient/medical-records": "Medical Records",
  "patient/prescriptions": "Prescriptions",
}

// Mock user data - in production, this should come from auth context
const PATIENT_NAME = "Alex Johnson"
const getPatientFirstName = () => {
  return PATIENT_NAME.split(" ")[0] || PATIENT_NAME
}

function formatTitle(segment?: string) {
  if (!segment) {
    return 'Dashboard'
  }

  return segment
    .split('-')
    .map((part) => part.charAt(0).toUpperCase() + part.slice(1))
    .join(' ')
}

export function SiteHeader({ basePath }: { basePath?: string }) {
  const segments = useSelectedLayoutSegments()
  const pathSegments = [basePath, ...segments.filter(Boolean)].filter(Boolean) as string[]
  const pathKey = pathSegments.join('/')
  const fallbackSegment = pathSegments[pathSegments.length - 1]
  let defaultTitle = TITLE_MAP[pathKey] ?? formatTitle(fallbackSegment ?? basePath)
  const isPatientDashboard = pathKey === 'patient'
  
  // Set welcome message for patient dashboard
  if (isPatientDashboard && !defaultTitle) {
    const firstName = getPatientFirstName()
    defaultTitle = `Welcome back ${firstName}!`
  }
  const isDoctorAiAssistant = pathKey === 'doctor/ai-assistant'
  const isPatientAiChat = pathKey.startsWith('patient/ai-chat')
  const isPatientAiChatDetail = isPatientAiChat && pathSegments.length > 2
  const [conversationTitle, setConversationTitle] = useState<string | null>(null)

  const title = conversationTitle ?? defaultTitle

  useEffect(() => {
    if (!isDoctorAiAssistant) {
      setConversationTitle(null)
      return
    }

    const handleUpdateTitle = (event: Event) => {
      const customEvent = event as CustomEvent<{ title: string | null }>
      setConversationTitle(customEvent.detail.title)
    }

    window.addEventListener(
      DOCTOR_AI_ASSISTANT_UPDATE_TITLE_EVENT as keyof WindowEventMap,
      handleUpdateTitle as EventListener,
    )

    return () =>
      window.removeEventListener(
        DOCTOR_AI_ASSISTANT_UPDATE_TITLE_EVENT as keyof WindowEventMap,
        handleUpdateTitle as EventListener,
      )
  }, [isDoctorAiAssistant])

  const handleDoctorNewChat = () => {
    window.dispatchEvent(new Event(DOCTOR_AI_ASSISTANT_NEW_CHAT_EVENT))
  }

  const handleDoctorBackToList = () => {
    window.dispatchEvent(new Event(DOCTOR_AI_ASSISTANT_BACK_TO_LIST_EVENT))
    setConversationTitle(null)
  }

  let actions: ReactNode = null

  if (isPatientAiChat) {
    actions = (
      <Button asChild size="sm">
        <Link href="/patient/ai-chat/new">
          <IconPlus className="h-4 w-4" />
          New Consult
        </Link>
      </Button>
    )
  } else if (isDoctorAiAssistant) {
    actions = (
      <Button size="sm" onClick={handleDoctorNewChat}>
        <IconPlus className="h-4 w-4" />
        New chat
      </Button>
    )
  }

  return (
    <header className="flex h-16 shrink-0 items-center justify-between px-5 lg:px-7 transition-[width,height] ease-linear group-has-data-[collapsible=icon]/sidebar-wrapper:h-16">
      <div className="flex items-center gap-3">
        <SidebarTrigger className="-ml-1" />
        {isDoctorAiAssistant && conversationTitle && (
          <button
            type="button"
            onClick={handleDoctorBackToList}
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted/50 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
            aria-label="Back to consultations"
          >
            <IconArrowLeft className="h-4 w-4" />
          </button>
        )}
        {isPatientAiChatDetail ? (
          <Link
            href="/patient/ai-chat"
            className="inline-flex h-8 w-8 items-center justify-center rounded-lg text-muted-foreground transition-colors hover:bg-muted/50 hover:text-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/20"
            aria-label="Back to chats"
          >
            <IconArrowLeft className="h-4 w-4" />
          </Link>
        ) : null}
        {title ? <span className="text-xl font-semibold leading-none">{title}</span> : null}
      </div>
      {actions ? <div className="flex items-center gap-2">{actions}</div> : null}
    </header>
  )
}
