"use client"

import { IconMoon, IconSun } from "@tabler/icons-react"
import { useThemeMode } from "@/hooks/use-theme-mode"
import {
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
} from "@/components/ui/sidebar"

export function SidebarThemeToggle() {
  const { theme, setTheme } = useThemeMode()
  const isDark = theme === "dark"
  const Icon = isDark ? IconSun : IconMoon
  const label = isDark ? "Light Mode" : "Dark Mode"

  return (
    <SidebarGroup>
      <SidebarGroupContent>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild>
              <button
                type="button"
                onClick={() => setTheme(isDark ? "light" : "dark")}
                className="flex w-full items-center gap-2"
              >
                <Icon className="shrink-0" />
                <span>{label}</span>
              </button>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarGroupContent>
    </SidebarGroup>
  )
}

