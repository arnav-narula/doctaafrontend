"use client"

import { SidebarMenuButton } from "@/components/ui/sidebar"

import type * as React from "react"
import {
  IconStethoscope,
  IconLayoutDashboard,
  IconUsers,
  IconFileText,
  IconSettings,
  IconHelp,
  IconSearch,
  IconPhone,
  IconBell,
} from "@tabler/icons-react"

import { NavDocuments } from "@/components/nav-documents"
import { NavMain } from "@/components/nav-main"
import { NavSecondary } from "@/components/nav-secondary"
import { NavUser } from "@/components/nav-user"
import { SidebarThemeToggle } from "@/components/sidebar-theme-toggle"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
} from "@/components/ui/sidebar"

const data = {
  user: {
    name: "Dr. Sarah Chen",
    email: "sarah.chen@telehealthcare.com",
    avatar: "/avatars/shadcn.jpg",
  },
  navMain: [
    {
      title: "Dashboard",
      url: "/doctor",
      icon: IconLayoutDashboard,
    },
    {
      title: "Consultations",
      url: "/doctor/consultations",
      icon: IconPhone,
    },
    {
      title: "Patients",
      url: "/doctor/patients",
      icon: IconUsers,
    },
    {
      title: "Prescriptions",
      url: "/doctor/prescriptions",
      icon: IconBell,
    },
    {
      title: "AI Assistant",
      url: "/doctor/ai-assistant",
      icon: IconStethoscope,
    },
  ],
  documents: [],
  navSecondary: [
    {
      title: "Settings",
      url: "#",
      icon: IconSettings,
    },
    {
      title: "Get Help",
      url: "#",
      icon: IconHelp,
    },
    {
      title: "Search",
      url: "#",
      icon: IconSearch,
    },
  ],
}

export function AppSidebar({ ...props }: React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar collapsible="offcanvas" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild className="data-[slot=sidebar-menu-button]:!p-1.5">
              <a href="#">
                <IconStethoscope className="!size-5" />
                <span className="text-base font-semibold">TeleHealth AI</span>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
        {data.documents.length > 0 ? <NavDocuments items={data.documents} /> : null}
        <div className="mt-auto space-y-2">
          <NavSecondary items={data.navSecondary} />
          <SidebarThemeToggle />
        </div>
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={data.user} />
      </SidebarFooter>
    </Sidebar>
  )
}
