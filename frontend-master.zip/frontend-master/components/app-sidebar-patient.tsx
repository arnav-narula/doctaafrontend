"use client"

import { SidebarMenuButton } from "@/components/ui/sidebar"

import type * as React from "react"
import {
  IconStethoscope,
  IconMessage,
  IconCalendar,
  IconFileText,
  IconHeartHandshake,
  IconHistory,
} from "@tabler/icons-react"

import { NavDocuments } from "@/components/nav-documents"
import { NavMain } from "@/components/nav-main"
import { NavUser } from "@/components/nav-user"
import {
  Sidebar,
  SidebarContent,
  SidebarFooter,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
} from "@/components/ui/sidebar"

const data = {
  user: {
    name: "Alex Johnson",
    email: "alex.johnson@email.com",
    avatar: "/avatars/shadcn.jpg",
  },
  navMain: [
    {
      title: "Health Dashboard",
      url: "/patient",
      icon: IconHeartHandshake,
    },
    {
      title: "AI Doctor Chats",
      url: "/patient/ai-chat",
      icon: IconMessage,
    },
    {
      title: "Appointments",
      url: "/patient/appointments",
      icon: IconCalendar,
    },
    {
      title: "Consultation History",
      url: "/patient/consultation-history",
      icon: IconHistory,
    },
  ],
  documents: [
    {
      name: "Medical Records",
      url: "/patient/medical-records",
      icon: IconFileText,
    },
    {
      name: "Prescriptions",
      url: "/patient/prescriptions",
      icon: IconStethoscope,
    },
  ],
}

export function AppSidebarPatient({ ...props }: React.ComponentProps<typeof Sidebar>) {
  return (
    <Sidebar collapsible="offcanvas" {...props}>
      <SidebarHeader>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton asChild className="data-[slot=sidebar-menu-button]:!p-1.5">
              <a href="#">
                <IconStethoscope className="!size-5" />
                <span className="text-base font-semibold">TeleHealth AI</span>
              </a>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarHeader>
      <SidebarContent>
        <NavMain items={data.navMain} />
        <NavDocuments items={data.documents} />
      </SidebarContent>
      <SidebarFooter>
        <NavUser user={data.user} />
      </SidebarFooter>
    </Sidebar>
  )
}
